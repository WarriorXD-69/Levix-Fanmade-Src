<p align="center">
  <a href="https://github.com/WarriorXD-69?tab=followers"><img src="https://img.shields.io/github/followers/WarriorXD-69?label=Follow&style=flat&color=8c52ff"></a>
  <a href="https://discord.gg/mrontop" target="_blank"><img src="https://img.shields.io/badge/Discord-%237289DA.svg?style=flat&logo=discord&logoColor=white&color=8c52ff"></a>

<p align="center">
  <img src="https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&pause=1000&color=ff0000&center=true&vCenter=true&width=380&lines=Hey+I'm+Warrior;I'm+a+Python+Developer;I+Made+Tools+Such+As..;Rascal+Nuker;Rascal+Selfbot;Alice+&+Fizer+Bots" alt="Typing SVG">
</p>

---

<p align="center">
  <img src="https://github-readme-stats.vercel.app/api/?username=WarriorXD-69&amp;title_color=5c64f4&amp;text_color=ff0000&amp;show_icons=true&amp;bg_color=00000000&amp;hide_border=true&amp;icon_color=5c64f4&amp;hide_title=true&amp;count_private=true">
</p>

<p align="center">
  <img src="https://github-readme-stats.vercel.app/api/top-langs/?username=WarriorXD-69&layout=compact&title_color=5c64f4&text_color=ff0000&bg_color=00000000&hide_border=true&count_private=true" />
</p>

---

<p align="center">
  <strong>Owner of <a href="https://discord.gg/mrontop" target="_blank">Rascals Developments</a></strong>
</p>

<p align="center">
  <a href="https://github.com/WarriorXD-69?tab=repositories"><img src="https://img.shields.io/badge/-Explore%20my%20Repos-24292e?style=for-the-badge&logo=Github"></a>
</p>

<p align="center">
  <a href="https://discord.com/users/1030928299620302960" target="_blank">
    <img src="https://i.ibb.co/QYYg10J/20250111-094429.png">
  </a>
</p>

---

<p align="center">
  <i>Socials</i>
  <br>
  <a href="https://discord.gg/mrontop"><img src="https://img.shields.io/badge/Discord-%237289DA.svg?style=flat&logo=discord&logoColor=white"></a>
  <a href="https://www.youtube.com/@Warriorjija"><img src="https://img.shields.io/badge/YouTube-FF0000.svg?style=flat&logo=youtube&logoColor=white"></a>
</p>
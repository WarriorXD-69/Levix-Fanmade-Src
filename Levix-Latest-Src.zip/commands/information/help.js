const { MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

module.exports = {
    name: 'help',
    aliases: ['h'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        const prefix = message.guild?.prefix || '&'; // Default prefix if not set

        // Create a MessageSelectMenu
        const selectMenu = new MessageSelectMenu()
            .setCustomId('categorySelect')
            .setPlaceholder('Levix Get Started!')
            .addOptions([
                {
                    label: 'Home',
                    value: 'home',
                    description: 'Return to the help menu',
                },
                {
                    label: 'All',
                    value: 'all',
                    description: 'Show all commands',
                },
                {
                    label: 'AntiNuke',
                    value: 'antinuke',
                    description: 'Commands related to AntiNuke',
                },
                {
                    label: 'Moderation',
                    value: 'mod',
                    description: 'Commands related to Moderation',
                },
                {
                    label: 'Utility',
                    value: 'info',
                    description: 'Utility commands',
                },
                {
                    label: 'Welcomer',
                    value: 'welcomer',
                    description: 'Commands for Welcomer',
                },
                {
                    label: 'Voice',
                    value: 'voice',
                    description: 'Commands related to Voice',
                },
                {
                    label: 'Automod',
                    value: 'automod',
                    description: 'Commands for Automod',
                },
                {
                    label: 'Custom Role',
                    value: 'customrole',
                    description: 'Commands for Custom Roles',
                },
                {
                    label: 'Logging',
                    value: 'logging',
                    description: 'Commands for Logging',
                },
                {
                    label: 'Autoresponder',
                    value: 'autoresponder',
                    description: 'Commands for Autoresponder',
                },
                {
                    label: 'Giveaway',
                    value: 'give',
                    description: 'Commands for Giveaway',
                },
                {
                    label: 'Fun',
                    value: 'fun',
                    description: 'Fun commands',
                }
            ]);

        // Create action row with buttons
        const actionRow = new MessageActionRow()
            .addComponents(
                new MessageButton()
                    .setLabel('Invite Me')
                    .setStyle('LINK')
                    .setURL('https://discord.com/oauth2/authorize?client_id=1218226477938511872&scope=bot%20applications.commands&permissions=8'),
                new MessageButton()
                    .setLabel('Support')
                    .setStyle('LINK')
                    .setURL('https://discord.gg/mrontop'),
                new MessageButton()
                    .setLabel('Home')
                    .setCustomId('homeButton')
                    .setStyle('SECONDARY'),
                new MessageButton()
                    .setLabel('Delete')
                    .setCustomId('deleteButton')
                    .setStyle('DANGER')
            );

        // Embed message
        const embed = new MessageEmbed()
            .setColor(client.color) // Red color for the embed
            .setAuthor({
                name: message.author.tag,
                iconURL: message.author.displayAvatarURL({ dynamic: true })
            })
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .setDescription(
                `Hello! I'm Levix, your server security bot with powerful Antinuke features.\n\nPrefix for this server \`${prefix}\`\nTotal Commands: \`${client.commands.size}\`\n Type \`${prefix}antinuke enable\``
            )
            .addField(
                '__Main Modules__',
                `
                <:antinuke:1340583476562497576> **AntiNuke**\n<:mod:1340583491863056444> **Moderation**\n<:logger:1340583482522341397> **Logging**\n<:utility:1340584088351936512> **Utility**\n<:welcomer:1340583466378592336> **Welcomer**\n<:fun:1340583488025526346> **Fun**
                `,
                true
            )
            .addField(
                '__Extra Modules__',
                `
                <:voice:1340583468853231757> **Voice**\n<:customrole:1340583458820587601> **Custom Role**\n<:automod:1340583485592834108> **Automod**\n<:autoresponder:1340583471034273874> **Autoresponder**\n<:gws:1340583474104369242> **Giveaway**\n
                `,
                true
            )
            .addField(
                '**Links**',
                `[Support](https://discord.gg/mrontop) **|** [Invite Me](https://discord.com/oauth2/authorize?client_id=1218226477938511872&scope=bot%20applications.commands&permissions=8)`,
                false
            )
            .setFooter({
                text: 'Developed By Warrior xD',
                iconURL: client.user.displayAvatarURL()
            });

        // Send the initial help message
        const helpMessage = await message.channel.send({
            embeds: [embed],
            components: [actionRow, new MessageActionRow().addComponents(selectMenu)]
        });

        // Component collector for interactions
        const collector = helpMessage.createMessageComponentCollector({
            filter: (i) => i.user.id === message.author.id,
            time: 6000000000
        });

        collector.on('collect', async (i) => {
            if (i.customId === 'deleteButton') {
                await helpMessage.delete();
                return;
            }

            if (i.customId === 'homeButton' || i.values?.[0] === 'home') {
                await i.deferUpdate();
                return helpMessage.edit({
                    embeds: [embed],
                    components: [actionRow, new MessageActionRow().addComponents(selectMenu)]
                });
            }

            await i.deferUpdate();

            const category = i.values[0];
            let commands = [];

            if (category === 'all') {
                commands = client.commands.map((x) => `\`${x.name}\``);
            } else {
                const categoryMap = {
                    antinuke: 'security',
                    mod: 'mod',
                    info: 'info',
                    welcomer: 'welcomer',
                    voice: 'voice',
                    automod: 'automod',
                    customrole: 'customrole',
                    logging: 'logging',
                    autoresponder: 'autoresponder',
                    giveaway: 'giveaway',
                    fun: 'fun',
                    ticket: 'ticket'
                };
                const filteredCategory = categoryMap[category];
                commands = client.commands
                    .filter((x) => x.category === filteredCategory)
                    .map((x) => `\`${x.name}\``);
            }

            const categoryEmbed = new MessageEmbed()
                .setColor(client.color)
                .setAuthor({
                    name: client.user.username,
                    iconURL: client.user.displayAvatarURL()
                })
                .setDescription(
                    `**${category.charAt(0).toUpperCase() + category.slice(1)} Commands**\n${commands.join(', ')}`
                );

            helpMessage.edit({
                embeds: [categoryEmbed],
                components: [actionRow, new MessageActionRow().addComponents(selectMenu)]
            });
        });

        collector.on('end', collected => {
            if (collected.size === 0) {
                helpMessage.edit({ components: [] });
            }
        });
    }
};
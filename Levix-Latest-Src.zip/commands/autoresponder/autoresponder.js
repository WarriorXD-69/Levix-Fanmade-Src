const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'autoresponder',
    aliases: ['ar'],
    category: 'autoresponder',
    description: 'Set, add, remove, or list autoresponder triggers and replies',
    run: async (client, message, args) => {
        // Check if the user has necessary permissions
        if (!message.member.permissions.has('MANAGE_MESSAGES') && message.guild.ownerId !== message.member.id) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:cross:1340580414343090256> | You must be the **Guild Owner** or have \`Manage Messages\` permission to use this command.`
                        ),
                ],
            });
        }

        // Ensure the first argument is valid for either 'add', 'remove', or 'list'
        const action = args[0]?.toLowerCase();
        if (!action || (action !== 'add' && action !== 'remove' && action !== 'list')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:cross:1340580414343090256> | Please specify whether to \`add\`, \`remove\`, or \`list\` the autoresponder.`
                        ),
                ],
            });
        }

        if (action === 'add') {
            // Ensure proper format of arguments for adding
            if (args.length < 3) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor('#00FFFF')
                            .setDescription(
                                `<:cross:1340580414343090256> | Please provide both a trigger phrase and a reply message to add.`
                            ),
                    ],
                });
            }

            const trigger = args[1].toLowerCase(); // Trigger phrase
            const replyMessage = args.slice(2).join(' '); // The reply message

            // Store the trigger and reply in an in-memory object (or database for persistent storage)
            client.autoresponders = client.autoresponders || {};

            // Ensure the trigger is unique
            if (client.autoresponders[trigger]) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor('#00FFFF')
                            .setDescription(
                                `<:cross:1340580414343090256> | An autoresponder for this trigger already exists.`
                            ),
                    ],
                });
            }

            // Add the trigger and reply to the bot's memory
            client.autoresponders[trigger] = replyMessage;

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:tick:1340580390166855751> | Successfully added an autoresponder for the trigger \`${trigger}\` with the reply: \`${replyMessage}\`.`
                        ),
                ],
            });

            // Listen for messages that match the trigger
            const triggerListener = (msg) => {
                if (msg.author.bot) return; // Ignore bot messages
                // Check if the message content contains the trigger (case-insensitive)
                if (msg.content.toLowerCase().includes(trigger)) {
                    msg.reply(replyMessage);
                }
            };
            // Store the listener in the bot's memory for later removal
            client.autoresponderListeners = client.autoresponderListeners || [];
            client.autoresponderListeners.push({ trigger, listener: triggerListener });

            // Attach the listener to the messageCreate event
            client.on('messageCreate', triggerListener);
        }

        if (action === 'remove') {
            // Ensure proper format of arguments for removing
            if (args.length < 2) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor('#00FFFF')
                            .setDescription(
                                `<:cross:1340580414343090256> | Please provide the trigger phrase to remove the autoresponder.`
                            ),
                    ],
                });
            }

            const triggerToRemove = args[1].toLowerCase(); // Trigger phrase to remove

            // Check if the trigger exists
            if (!client.autoresponders[triggerToRemove]) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor('#00FFFF')
                            .setDescription(
                                `<:cross:1340580414343090256> | No autoresponder found for the trigger \`${triggerToRemove}\`.`
                            ),
                    ],
                });
            }

            // Remove the trigger from the bot's memory
            delete client.autoresponders[triggerToRemove];

            // Find and remove the listener associated with this trigger
            const index = client.autoresponderListeners.findIndex(
                (entry) => entry.trigger === triggerToRemove
            );

            if (index !== -1) {
                const { listener } = client.autoresponderListeners.splice(index, 1)[0];

                // Remove the listener from the event
                client.off('messageCreate', listener);
            }

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:tick:1340580390166855751> | Successfully removed the autoresponder for the trigger \`${triggerToRemove}\`.`
                        ),
                ],
            });
        }

        if (action === 'list') {
            // Ensure there are autoresponders set up
            if (!Object.keys(client.autoresponders).length) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor('#00FFFF')
                            .setDescription(
                                `<:cross:1340580414343090256> | No autoresponders are currently set up.`
                            ),
                    ],
                });
            }

            // Create a formatted list of autoresponders
            const autoresponderList = Object.entries(client.autoresponders)
                .map(([trigger, reply]) => `**Trigger**: \`${trigger}\`\n**Reply**: \`${reply}\``)
                .join('\n\n');

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('BLUE')
                        .setTitle('Current Autoresponders')
                        .setDescription(autoresponderList),
                ],
            });
        }
    },
};

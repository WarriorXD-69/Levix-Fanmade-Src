const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'listjoinpos',
    aliases: ['joinposition', 'joinpos'],
    category: 'mod',
    cooldown: 5,
    permissions: ['MANAGE_GUILD'],
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);

        // Check if the user has the required permission to manage the server
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | You need the `MANAGE_GUILD` permission to use this command.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Fetch all members in the server
        const members = await message.guild.members.fetch();

        // Sort the members by their join date (earliest joined member first)
        const sortedMembers = members.sort((a, b) => a.joinedTimestamp - b.joinedTimestamp);

        // Create an embed with the list of join positions
        const joinPosEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Server Join Positions')
            .setDescription('Here is the list of members and their join positions in this server:')
            .setTimestamp()
            .setFooter(client.user.username, client.user.displayAvatarURL());

        // Adding the member join position info to the embed
        let joinPositions = '';
        sortedMembers.forEach((member, index) => {
            joinPositions += `${index + 1}. ${member.user.tag} (ID: ${member.user.id})\n`;
        });

        // If there are members, add the list to the embed
        if (joinPositions.length > 0) {
            joinPosEmbed.addField('Join Positions:', joinPositions);
        } else {
            joinPosEmbed.setDescription('<:cross:1340580414343090256> | No members found in this server.');
        }

        message.channel.send({ embeds: [joinPosEmbed] });
    }
};

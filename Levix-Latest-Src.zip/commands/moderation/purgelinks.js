const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'purgelinks',
    aliases: ['purgeurls', 'clearlinks'],
    category: 'mod',
    cooldown: 5,
    permissions: ['MANAGE_MESSAGES'],
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);

        // Check if the user has the required permission
        if (!message.member.permissions.has('MANAGE_MESSAGES')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription("<:cross:1340580414343090256> | You don't have the `MANAGE_MESSAGES` permission to use this command.")
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Set the number of messages to check for URLs (default: 100 messages)
        let limit = parseInt(args[0]) || 100; // Default to 100 messages if no number is provided

        if (limit > 100) limit = 100; // Limit to a maximum of 100 messages per purge

        try {
            const messages = await message.channel.messages.fetch({ limit });

            // Filter messages that contain URLs (links)
            const messagesWithLinks = messages.filter(msg => {
                const urlPattern = /(https?:\/\/[^\s]+)/g; // Regular expression to match URLs
                return urlPattern.test(msg.content);
            });

            // If no messages with links are found
            if (messagesWithLinks.size === 0) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setColor(client.color)
                            .setDescription("<:cross:1340580414343090256> | No links found to purge in the last 100 messages.")
                            .setTimestamp()
                            .setFooter(client.user.username, client.user.displayAvatarURL())
                    ]
                });
            }

            // Purge messages with links
            await message.channel.bulkDelete(messagesWithLinks, true);

            // Send confirmation message
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription(`<:tick:1340580390166855751> | Successfully purged ${messagesWithLinks.size} message(s) containing links from this channel.`)
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });

        } catch (error) {
            console.error(error);
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription("<:cross:1340580414343090256> | There was an error trying to purge messages containing links.")
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }
    }
};

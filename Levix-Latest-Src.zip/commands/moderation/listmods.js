const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'listmods',
    aliases: ['moderators'],
    category: 'mod',
    cooldown: 5,
    permissions: ['MANAGE_GUILD'],
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);

        // Check if the user has the required permission to manage the server
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | You need the `MANAGE_GUILD` permission to use this command.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Get all roles in the server (to check for roles that are typically given to moderators)
        const moderatorRoles = ['Moderator', 'Admin', 'Staff']; // Customize this list with your server's moderator roles

        // Fetch all members in the server
        const members = await message.guild.members.fetch();

        // Filter members who have any of the moderator roles
        const moderators = members.filter(member => 
            member.roles.cache.some(role => moderatorRoles.includes(role.name))
        );

        if (moderators.size === 0) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | There are no moderators in this server.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Create an embed with the list of moderators
        const modListEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Moderators in Server')
            .setDescription('Here is the list of moderators in this server:')
            .addField('Moderators', moderators.map(mod => `${mod.user.tag} (ID: ${mod.user.id})`).join('\n'), true)
            .setTimestamp()
            .setFooter(client.user.username, client.user.displayAvatarURL());

        message.channel.send({ embeds: [modListEmbed] });
    }
};

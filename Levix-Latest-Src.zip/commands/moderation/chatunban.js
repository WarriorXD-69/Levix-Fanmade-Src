const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'chatunban',
    category: 'mod',
    run: async (client, message, args) => {
        // Check if the user has necessary permissions
        if (!message.member.permissions.has('MANAGE_CHANNELS') && message.guild.ownerId !== message.member.id) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:cross:1340580414343090256> | You must be the **Guild Owner** or have \`Manage Channels\` permission to use this command.`
                        ),
                ],
            });
        }

        const member =
            message.mentions.members.first() ||
            message.guild.members.cache.get(args[0]);

        if (!member) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:cross:1340580414343090256> | You must mention a user or provide their ID to chatunban.`
                        ),
                ],
            });
        }

        // Prevent banning the guild owner or the bot itself
        if (member.id === message.guild.ownerId || member.id === client.user.id) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(`<:cross:1340580414343090256> | You cannot chatunban this user.`),
                ],
            });
        }

        try {
            // Set permissions to deny sending messages in all channels
            message.guild.channels.cache.forEach((channel) => {
                if (channel.isText()) {
                    channel.permissionOverwrites.create(member, {
                        SEND_MESSAGES: true,
                    });
                }
            });

            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:tick:1340580390166855751> | Successfully chatunbanned <@${member.user.id}>.`
                        ),
                ],
            });
        } catch (err) {
            console.error(err);
            message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription(
                            `<:cross:1340580414343090256> | An error occurred while trying to chatunban <@${member.user.id}>.`
                        ),
                ],
            });
        }
    },
};
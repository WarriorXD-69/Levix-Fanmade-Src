const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'listbans',
    aliases: ['bans'],
    category: 'mod',
    cooldown: 5,
    permissions: ['BAN_MEMBERS'],
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);

        // Check if the user has the required permission to ban members
        if (!message.member.permissions.has('BAN_MEMBERS')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | You need the `BAN_MEMBERS` permission to use this command.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        try {
            // Fetch the list of banned users in the server
            const bans = await message.guild.bans.fetch();
            
            if (bans.size === 0) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setColor(client.color)
                            .setDescription('<:cross:1340580414343090256> | There are no banned users in this server.')
                            .setTimestamp()
                            .setFooter(client.user.username, client.user.displayAvatarURL())
                    ]
                });
            }

            // Create the embed to display the list of banned users
            const banListEmbed = new MessageEmbed()
                .setColor(client.color)
                .setTitle('Banned Users in Server')
                .setDescription('Here is the list of users banned from this server:')
                .addField('Banned Users', bans.map(ban => `${ban.user.tag} (ID: ${ban.user.id})`).join('\n'), true)
                .setTimestamp()
                .setFooter(client.user.username, client.user.displayAvatarURL());

            message.channel.send({ embeds: [banListEmbed] });
        } catch (error) {
            console.error(error);
            message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | An error occurred while fetching the bans.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }
    }
};

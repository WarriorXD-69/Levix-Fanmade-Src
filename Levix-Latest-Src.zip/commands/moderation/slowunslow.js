const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'slowmode',
    aliases: ['sm'],
    category: 'mod',
    cooldown: 5,
    permissions: ['MANAGE_CHANNELS'], // Ensure the user has permission to manage channels
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);
        
        // Check if the user has permission to manage channels
        if (!message.member.permissions.has('MANAGE_CHANNELS')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | You need the `MANAGE_CHANNELS` permission to use this command.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Get the time in seconds from arguments
        const time = args[0];

        // If no time is provided, show the current slowmode status
        if (!time) {
            const currentSlowmode = message.channel.rateLimitPerUser;
            if (currentSlowmode === 0) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setColor(client.color)
                            .setDescription('<:tick:1340580390166855751> | Slowmode is currently disabled in this channel.')
                            .setTimestamp()
                            .setFooter(client.user.username, client.user.displayAvatarURL())
                    ]
                });
            } else {
                return message.channel.send({
                    embeds: [
                        embed
                            .setColor(client.color)
                            .setDescription(`<:tick:1340580390166855751> | Slowmode is currently set to ${currentSlowmode} seconds in this channel.`)
                            .setTimestamp()
                            .setFooter(client.user.username, client.user.displayAvatarURL())
                    ]
                });
            }
        }

        // Check if the time is a valid number
        if (isNaN(time) || time < 0 || time > 21600) { // 21600 seconds = 6 hours
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | Please provide a valid number of seconds (1 - 21600).')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Set the slowmode (in seconds)
        try {
            await message.channel.setRateLimitPerUser(time);
            const successEmbed = new MessageEmbed()
                .setColor(client.color)
                .setDescription(`<:tick:1340580390166855751> | Slowmode has been set to ${time} seconds in this channel.`)
                .setTimestamp()
                .setFooter(client.user.username, client.user.displayAvatarURL());

            message.channel.send({ embeds: [successEmbed] });

        } catch (err) {
            console.error(err);
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | There was an error setting the slowmode.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }
    }
};

const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'auditcheck',
    aliases: ['audit'],
    category: 'mod',
    premium: false,
    run: async (client, message, args) => {
        // Check if the user has the necessary permission
        if (!message.member.permissions.has('VIEW_AUDIT_LOG')) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription(`You need \`VIEW_AUDIT_LOG\` permission to use this command.`)
                ]
            });
        }

        // Get the number of logs to fetch (default is 5 if not specified)
        const limit = args[0] && !isNaN(args[0]) ? parseInt(args[0], 10) : 5;

        if (limit > 10) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor(client.color)
                        .setDescription('You can only fetch up to 10 audit logs at once.')
                ]
            });
        }

        // Fetch the audit logs
        try {
            const auditLogs = await message.guild.fetchAuditLogs({ limit, type: 'ALL' });

            if (auditLogs.entries.size === 0) {
                return message.channel.send({
                    embeds: [
                        new MessageEmbed()
                            .setColor(client.color)
                            .setDescription('No audit logs found for this server.')
                    ]
                });
            }

            // Create an embed to display the audit logs
            const logsEmbed = new MessageEmbed()
                .setColor(client.color)
                .setTitle(`Audit Logs for ${message.guild.name}`)
                .setFooter({
                    text: `Requested by ${message.author.tag}`,
                    iconURL: message.author.displayAvatarURL({ dynamic: true })
                });

            // Add the log entries to the embed
            auditLogs.entries.forEach(log => {
                const executor = log.executor.tag;
                const target = log.target ? log.target.tag || log.target.name : 'Unknown';
                const action = log.action;
                const date = log.createdAt;

                logsEmbed.addField(
                    `**${executor}** performed an action:`,
                    `**Action Type:** ${action}\n**Target:** ${target}\n**Date:** ${date.toISOString()}`
                );
            });

            // Send the embed
            await message.channel.send({ embeds: [logsEmbed] });

        } catch (error) {
            console.error('Error fetching audit logs:', error);
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription('An error occurred while fetching audit logs.')
                ]
            });
        }
    }
};

const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'listbooster',
    aliases: ['boosters'],
    category: 'mod',
    cooldown: 5,
    permissions: ['MANAGE_GUILD'],
    run: async (client, message, args) => {
        const embed = new MessageEmbed().setColor(client.color);

        // Check if the user has the required permission to manage the server
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | You need the `MANAGE_GUILD` permission to use this command.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Fetch all members in the server
        const members = await message.guild.members.fetch();

        // Filter members who have boosted the server (check for premiumSince property)
        const boosters = members.filter(member => member.premiumSince);

        if (boosters.size === 0) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription('<:cross:1340580414343090256> | No one has boosted the server yet.')
                        .setTimestamp()
                        .setFooter(client.user.username, client.user.displayAvatarURL())
                ]
            });
        }

        // Create an embed with the list of boosters
        const boosterListEmbed = new MessageEmbed()
            .setColor(client.color)
            .setTitle('Boosters in Server')
            .setDescription('Here is the list of boosters in this server:')
            .addField('Boosters', boosters.map(booster => `${booster.user.tag} (ID: ${booster.user.id})`).join('\n'), true)
            .setTimestamp()
            .setFooter(client.user.username, client.user.displayAvatarURL());

        message.channel.send({ embeds: [boosterListEmbed] });
    }
};

const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'devrole',
  category: 'owner',
  description: 'Add a role to a user by finding the role ID.',
  usage: 'devrole <user_id> <role_id>',
  run: async (client, message, args) => {
    // Define the two owner IDs (replace with actual Discord user IDs)
    const ownerIds = ['1030928299620302960'];

    // Ensure the message author is one of the owners
    if (!ownerIds.includes(message.author.id)) {
      const embed = new MessageEmbed()
        .setColor('#ff0000')
        .setDescription('This command is restricted to the bot owners.');
      return message.channel.send({ embeds: [embed] });
    }

    // Ensure both user ID and role ID are provided
    if (!args[0] || !args[1]) {
      const embed = new MessageEmbed()
        .setColor('#ff0000')
        .setDescription('Please provide both user ID and role ID.');
      return message.channel.send({ embeds: [embed] });
    }

    // Extract user and role IDs from the arguments
    const userId = args[0];
    const roleId = args[1];
    
    // Try to find the user and role in the guild
    const user = message.guild.members.cache.get(userId);
    const role = message.guild.roles.cache.get(roleId);

    // Check if the user and role exist
    if (!user || !role) {
      const embed = new MessageEmbed()
        .setColor('#ff0000')
        .setDescription('Invalid user ID or role ID.');
      return message.channel.send({ embeds: [embed] });
    }

    // Add the role to the user
    try {
      await user.roles.add(role);
      
      // Success message upon adding the role
      const embed = new MessageEmbed()
        .setColor('#00ff00')
        .setDescription(`Successfully added role **${role.name}** to user **${user.user.tag}**.`);
      return message.channel.send({ embeds: [embed] });
    } catch (error) {
      // Handle any errors that occur while adding the role
      console.error('Error adding role:', error);
      const embed = new MessageEmbed()
        .setColor('#ff0000')
        .setDescription('Failed to add role. Please check the bot\'s permissions or try again later.');
      return message.channel.send({ embeds: [embed] });
    }
  }
};

const {
    Message,
    Client,
    MessageEmbed,
    MessageActionRow,
    MessageButton
} = require('discord.js');
const webhookUrl = 'https://discord.com/api/webhooks/1324700471906144318/UqXC8cAQJVaSIlFiKpzM3UpMtcdlFiOjhr3mmNQ5-XzuBekt5i4sGjru87D0_rgqF5Ao'; // Add your webhook URL here
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'noprefix',
    aliases: ['np'],
    category: 'owner',
    run: async (client, message, args) => {
        if (!this.config.np.includes(message.author.id)) return;

        const embed = new MessageEmbed().setColor(client.color);
        let prefix = message.guild.prefix;
        if (!args[0]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription(
                            `Please provide the required arguments.\n${prefix}noprefix \`<add/remove/list>\` \`<user id or mention>\``
                        )
                ]
            });
        }

        // Handle mention or user ID
        let userId;
        if (args[1]) {
            // Check if the second argument is a mention
            if (args[1].startsWith('<@') && args[1].endsWith('>')) {
                userId = args[1].replace(/[<@!>]/g, ''); // Extract the user ID from the mention
            } else {
                userId = args[1]; // Directly use the user ID if not a mention
            }
        }

        // Ensure the user exists
        let user = await client.users.fetch(userId).catch((er) => {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription(
                            `Unable to find a user with the ID or mention provided.\n${prefix}noprefix \`<add/remove/list>\` \`<user id or mention>\``
                        )
                ]
            });
        });

        let added = (await client.db.get(`noprefix_${client.user.id}`))
            ? await client.db.get(`noprefix_${client.user.id}`)
            : [];

        let opt = args[0].toLowerCase();

        if (opt == `list`) {
            let listing = added.length < 1 ? ['No Users ;-;'] : await Promise.all(added.map(async (id, i) => {
                let user = await client.users.fetch(id);
                return `${i + 1}) ${user.tag} (${user.id})`;
            }));
            return await client.util.pagination(message, listing, '**No Prefix Users List :-');
        }

        if (!args[1]) {
            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription(
                            `Please provide the required arguments.\n${prefix}noprefix \`<add/remove/list>\` \`<user id or mention>\``
                        )
                ]
            });
        }

        // Add user to no prefix list
        if (opt == `add` || opt == `a` || opt == `+`) {
            if (added.includes(user.id)) {
                return message.channel.send({
                    embeds: [
                        embed
                            .setDescription(`${client.emoji.cross} | <@${user.id}> is already in the **No Prefix** list.`)
                    ]
                });
            }
            added.push(user.id);
            added = client.util.removeDuplicates(added);
            await client.db.set(`noprefix_${client.user.id}`, added);
            client.util.noprefix();

            // Send to webhook
            const webhookEmbed = new MessageEmbed()
                .setColor(client.color)
                .setTitle('No Prefix Update')
                .setDescription(`**<@${message.author.id}>** added **<@${user.id}>** to the No Prefix list in **${message.guild.name}**.`)
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();
            client.channels.cache.get(webhookUrl).send({ embeds: [webhookEmbed] });

            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription(
                            `<:tick:1340580390166855751> | **<@${user.id}> (${user.id})** has been added as a **No Prefix** user.`
                        )
                ]
            });
        }

        // Remove user from no prefix list
        if (opt == `remove` || opt == `r` || opt == `-`) {
            added = added.filter((srv) => srv != user.id);
            added = client.util.removeDuplicates(added);
            await client.db.set(`noprefix_${client.user.id}`, added);
            client.util.noprefix();

            // Send to webhook
            const webhookEmbed = new MessageEmbed()
                .setColor(client.color)
                .setTitle('No Prefix Update')
                .setDescription(`**<@${message.author.id}>** removed **<@${user.id}>** from the No Prefix list in **${message.guild.name}**.`)
                .setAuthor({ name: message.author.tag, iconURL: message.author.displayAvatarURL() })
                .setTimestamp();
            client.channels.cache.get(webhookUrl).send({ embeds: [webhookEmbed] });

            return message.channel.send({
                embeds: [
                    embed
                        .setColor(client.color)
                        .setDescription(
                            `<:tick:1340580390166855751> | **<@${user.id}> (${user.id})** has been removed from the **No Prefix** list.`
                        )
                ]
            });
        }

        // Default case
        message.channel.send({
            embeds: [
                embed
                    .setColor(client.color)
                    .setDescription(
                        `${prefix}noprefix \`<add/remove/list>\` \`<user id or mention>\``
                    )
            ]
        });
    }
};

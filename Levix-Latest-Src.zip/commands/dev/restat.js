const { MessageEmbed } = require('discord.js');
const ricky = ['1030928299620302960']; // Owner IDs

module.exports = {
    name: 'restart', // Restart command name
    aliases: ['reboot', 're'], // Possible aliases for restart
    category: 'Owner',
    run: async (client, message, args) => {
        // Check if the user is an authorized owner
        if (!ricky.includes(message.author.id)) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setColor('#00FFFF')
                        .setDescription('<:cross:1340580414343090256> You don\'t have permission to use this command!')
                ]
            });
        }

        // Send a confirmation message that the bot is restarting
        const restartEmbed = new MessageEmbed()
            .setColor('#00FFFF')
            .setDescription('<:tick:1340580390166855751> The bot is restarting... Please wait.');

        await message.channel.send({ embeds: [restartEmbed] });

        // If the bot is hosted on a process manager like PM2, we can use process.exit() to restart it
        try {
            // Restart the bot by exiting the process
            console.log('Bot is restarting...');
            process.exit(1); // PM2 or other process managers will automatically restart the bot
        } catch (error) {
            console.error('Error restarting the bot:', error);
            const errorEmbed = new MessageEmbed()
                .setColor('#00FFFF')
                .setDescription('<:cross:1340580414343090256> An error occurred while restarting the bot.');
            return message.channel.send({ embeds: [errorEmbed] });
        }
    }
};
const { MessageEmbed } = require('discord.js');
const { activeGiveaways } = require('./gstart'); // Import active giveaways object

module.exports = {
    name: 'gpause',
    description: 'Pause an ongoing giveaway.',
    category: 'giveaway',
    usage: 'gpause <message_id>',

    async run(client, message, args) {
        const giveawayId = args[0];

        if (!giveawayId) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> Please provide the giveaway message ID to pause the giveaway.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Check if the giveaway is active
        const giveaway = activeGiveaways[giveawayId];
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> No active giveaway found with that ID.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Check if giveaway is already paused
        if (giveaway.paused) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> The giveaway is already paused.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Pause the giveaway
        clearTimeout(giveaway.timer);

        // Mark the giveaway as paused
        giveaway.paused = true;

        // Send a confirmation message
        message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setDescription(`<:cross:1340580414343090256> The giveaway for **${giveaway.prize}** has been paused by ${message.author}.`)
                    .setColor('#00FFFF')
            ]
        });

        // Save the remaining time before pausing
        giveaway.remainingTime = giveaway.remainingTime - (Date.now() - giveaway.endTime);

        // Update the embed to indicate the giveaway is paused
        const pausedEmbed = new MessageEmbed()
            .setTitle('🎉 Levix Giveaway Paused!🎉')
            .setDescription(`**<a:cyan_dot:1340585319480688672> Prize:** ${giveaway.prize}
**<a:cyan_dot:1340585319480688672> Duration:** ${giveaway.remainingTime / 1000}s (paused)
**<a:cyan_dot:1340585319480688672> Hosted By:** ${giveaway.host}`)
            .setColor('#00FFFF')
            .setFooter('Giveaway paused, use gresume to resume.');

        giveaway.message.edit({ embeds: [pausedEmbed] });
    },
};

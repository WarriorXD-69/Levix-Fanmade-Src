const { MessageEmbed } = require('discord.js');
const { activeGiveaways } = require('./gstart'); // Import active giveaways object

module.exports = {
    name: 'gstop',
    description: 'Stop an ongoing giveaway.',
    category: 'giveaway',
    usage: 'gstop <message_id>',

    async run(client, message, args) {
        const giveawayId = args[0];

        if (!giveawayId) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> Please provide the giveaway message ID to stop the giveaway.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Check if the giveaway is active
        const giveaway = activeGiveaways[giveawayId];
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> No active giveaway found with that ID.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Clear the timeout and stop the giveaway
        clearTimeout(giveaway.timer);

        // Remove reactions
        await giveaway.message.reactions.removeAll();

        // Notify that the giveaway was stopped
        giveaway.channel.send({
            embeds: [
                new MessageEmbed()
                    .setDescription(`<:cross:1340580414343090256> The giveaway for **${giveaway.prize}** has been stopped by ${message.author}.`)
                    .setColor('#00FFFF')
            ]
        });

        // Clean up the active giveaway
        delete activeGiveaways[giveawayId];
    },
};

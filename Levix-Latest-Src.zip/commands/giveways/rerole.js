const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'greroll',
    description: 'Reroll a giveaway.',
    category: 'giveaway',
    usage: 'greroll <message_id>',

    async run(client, message, args) {
        // Check permissions
        if (!message.member.permissions.has('MANAGE_GUILD')) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> You need `Manage Server` permission to reroll a giveaway.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Get the message ID of the giveaway
        const giveawayMessageId = args[0];
        if (!giveawayMessageId) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> Please provide a valid giveaway message ID.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Fetch the giveaway data from the stored giveaways
        const giveaway = client.giveaways && client.giveaways[giveawayMessageId];
        if (!giveaway) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> No giveaway found with that message ID.')
                        .setColor('#00FFFF')
                ]
            });
        }

        // Get the giveaway message
        const giveawayMessage = await message.channel.messages.fetch(giveawayMessageId);

        // React to the message with 🎉
        const reaction = giveawayMessage.reactions.cache.get('🎉');
        if (!reaction) {
            return message.reply({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> Giveaway message does not have reactions!')
                        .setColor('#00FFFF')
                ]
            });
        }

        const users = await reaction.users.fetch();
        const participants = users.filter((u) => !u.bot).random(giveaway.winnerCount);

        if (!participants.length) {
            return message.channel.send({
                embeds: [
                    new MessageEmbed()
                        .setDescription('<:cross:1340580414343090256> No valid participants, giveaway canceled.')
                        .setColor('#00FFFF')
                ]
            });
        }

        const winners = participants.map((u) => `<@${u.id}>`).join(', ');
        message.channel.send({
            embeds: [
                new MessageEmbed()
                    .setTitle('🎉 Levix Giveaway Rerolled!🎉')
                    .setDescription(`**<a:cyan_dot:1340585319480688672> Prize:** ${giveaway.prize}
**<a:cyan_dot:1340585319480688672> New Winners:** ${winners}
**<a:cyan_dot:1340585319480688672> Hosted By:** ${message.author}`)
                    .setColor('#00FFFF')
            ]
        });
    },
};